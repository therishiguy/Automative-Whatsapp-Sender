from selenium import webdriver
import time

driver = webdriver.Chrome('/Users/RishiGandhi/Documents/Drivers/ChromeDrive')
driver.get('https://web.whatsapp.com/')

name = input('Enter the name')
msg = input('Enter your Messege:')
count = int(input('Enter the count'))

input('Enter any key after scanning qr code')


user = driver.find_element_by_xpath('//span[@title = "{}"]'.format(name))
user.click()
time.sleep(2)



msg_box = driver.find_element_by_xpath('//*[@id="main"]/footer/div[1]/div[2]/div/div[2]')


for i in range(count):
    msg_box.send_keys(msg)
    time.sleep(2)
    button = driver.find_element_by_class_name('_1U1xa')
    button.click()








